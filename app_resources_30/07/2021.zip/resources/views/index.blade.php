@extends('layouts.app')
@section('title', $settings['home_meta_title'] ?? '')
@section('meta')
<meta name="description" content="{{ $settings['home_meta_description'] ?? '' }}">
<meta name="keywords" content="{{ $settings['home_meta_keywords'] ?? '' }}">
@endsection

@section('css')
<style>
.slick-tutors .container-thumbnail {
  position: relative;
  width: 50%;
}

.slick-tutors .image {
  opacity: 1;
  display: block;
  width: 100%;
  height: auto;
  transition: .5s ease;
  backface-visibility: hidden;
}

.slick-tutors .middle {
  transition: .5s ease;
  opacity: 0.9;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  text-align: center;
}

.slick-tutors .container-thumbnail:hover .image {
  opacity: 0.3;
}

.slick-tutors .container-thumbnail:hover .middle {
  opacity: 1;
}

.slick-tutors .text {
  background-color: #3aafa9;
  color: white;
  font-size: 13px;
  padding: 12px 24px;
  cursor: pointer;
}
</style>
@endsection

@section('content')

<!-- content begin -->
<div class="no-bottom no-top" id="content">
    <div id="top"></div>

    <section class="container-banner-lg p-0">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6 col-md-12 col-sm-12 banner-left-heading m-auto">
                    <div class="banner-left-area">
                        <div class="alhamdulillah-dark custom-font-1 mb-3">Alhamdulillah</div>
                        <h1 class="text-dark custom-font-3 type-js"><strong class="text-js text-dark">One-to-One online Quran tutoring that delivers results</strong><i class="fa fa-circle blinked-circle"></i></h1>
                        <p class="text-justify text-dark">An online learning platform designed to cater for Muslims who seek the ability to read The Holy Quran all from the comfort of their own home.</p>
                        <div style="width: 155px;"><a href="{{ route('enroll') }}" class="btn btn-custom btn-sitea">Start Free Trial</a></div>
                        <div class="mt-2">
                            <a href="javascript:;"><img src="{{ asset('images/trustpilot.png') }}" style="width:100px;" class="img-fluid" alt="Trustpilot"></a>
                            <a href="https://bit.ly/37tlXz8" class="" target="_blank"><img src="{{ asset('images/google.png') }}" style="width:140px;" class="img-fluid" alt="Google Reviews"></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 asideimg" style="background-image: linear-gradient(0deg, rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url({{ asset($settings['header_banner_image']) }});"></div>
                {{-- <div class="col-lg-6 col-md-6 col-sm-12 asideimg" style="background-image: url({{ asset($settings['header_banner_image']) }});">

                </div> --}}
            </div>
        </div>
    </section>
    <section class="container-banner-md p-0" style="background-image: linear-gradient(0deg, rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url({{ asset($settings['header_banner_image']) }});">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-12 col-sm-12 banner-left-heading m-auto">
                    <div class="banner-left-area">
                        <div class="alhamdulillah-white custom-font-1 mb-3">Alhamdulillah</div>
                        <h1 class="text-white custom-font-3"><span>One-to-One</span> online Quran tutoring that delivers results<i class="fab fa-circle blinked-circle"></i></h1>
                        <p class="text-justify text-white">An online learning platform designed to cater for Muslims who seek the ability to read The Holy Quran all from the comfort of their own home.</p>
                        <div style="width: 170px;"><a href="" class="btn-slider">Start Free Trial</a></div>
                        <div class="mt-2">
                            <a href="javascript:;"><img src="{{ asset('images/trustpilot.png') }}" style="width:100px;" class="img-fluid" alt="Trustpilot"></a>
                            <a href="https://bit.ly/37tlXz8" class="mt-2" target="_blank"><img src="{{ asset('images/google.png') }}" style="width:100px;" class="img-fluid" alt="Google Reviews"></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-12"></div>
            </div>
        </div>
    </section>

    <section class="section-reviews">
        <div class="container text-center">
            <div class="row mt-2">
                <div class="col-lg-4 col-md-4">
                    <h3>used by 500+ students</h3>
                </div>
                <div class="col-lg-4 col-md-4">
                    <h3>40+ professional tutors</h3>
                </div>
                <div class="col-lg-4 col-md-4">
                    <h3>{{ number_format($review) }}
                        <span class="header-rating-star">
                            <i class="fa fa-star" aria-hidden="true"></i>
                            <i class="fa fa-star" aria-hidden="true"></i>
                            <i class="fa fa-star" aria-hidden="true"></i>
                            <i class="fa fa-star" aria-hidden="true"></i>
                            <i class="fa fa-star" aria-hidden="true"></i>
                        </span>
                        <a href="{{route('testimonials')}}">reviews</a>
                    </h3>
                </div>
            </div>
        </div>
    </section>

    <section class="section-lesson pt-3 pb-3">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 m-auto lessons-left-heading">
                    <div class="alhamdulillah-dark custom-font-1">Alhamdulillah</div>
                    <h1>Quran lessons from<br> <span>£4 per hour</span></h1>
                    <p>
                        Start learning with professional and experienced online Quran teachers who are not only selected for their knowledge, but also for their drive-in encouraging students’ self-motivation and passion towards understanding the Holy Quran.
                    </p>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 text-center">
                    <img src="{{ asset("images/second_banner.png") }}" class="img-fluid" alt="">
                </div>
            </div>
        </div>
    </section>

    <section class="section-fun-learning pb-3 bg-white">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 p-5 sm-order-1 order-2">
                    <img src="{{ asset('images/expert.png') }}" class="img-fluid" alt="">
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 m-auto fun-learning-right-heading sm-order-2 order-1">
                    <div class="alhamdulillah-dark custom-font-1 mb-3">Alhamdulillah</div>
                    <h1><span>Learn Tajweed-ul-Quran</span> rules with expert teachers </h1>
                    <p>
                        Our Male and Female Quran teachers are well versed and qualified. During our selection process we thoroughly vet and personally interview every tutor, we pride ourselves with an average acceptance rate of 1 in 10 applicants.
                    </p>
                </div>
            </div>
        </div>
    </section>

    <section class="section-lesson pb-3">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 m-auto lessons-left-heading">
                    <div class="alhamdulillah-dark custom-font-1 mb-3">Alhamdulillah</div>
                    <h1><span>Interactive Quran</span> classes with whiteboard & screen sharing </h1>
                    <p>
                        We use the latest software such as video streaming, interactive whiteboards, screen sharing and multi-channel audio to make Quran reading a versatile learning experience.
                    </p>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <img src="{{ asset('images/one2one.png') }}" class="img-fluid" alt="">
                </div>
            </div>
        </div>
    </section>

    <section class="section-lesson pb-3 bg-white">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 sm-order-1">
                    <img src="{{ asset('images/trial.png') }}" class="img-fluid p-2" alt="">
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 m-auto lessons-left-heading sm-order-2">
                    <div class="alhamdulillah-dark custom-font-1 mb-3">Alhamdulillah</div>
                    <h1><span>It’s flexible</span>, saves time and fits effortlessly into family life.</h1>
                    <p>
                        Our online learning platform is designed to transcend learning boundaries, enabling more efficient time management. There is no longer a need to wait your turn in a busy classroom environment or commute to cram into the schedule of a madrassa. We have the most innovative and flexible programs created to engage and nurture learning to help preserve the sacred message of the Holy Quran.
                    </p>
                </div>
            </div>
        </div>
    </section>

   

    <section class="section-handpicked pt-3 pb-3" id="inquiry-form">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 p-5 handpicked-right-heading sm-order-1 order-2">
                    <div class="alhamdulillah-dark custom-font-1 mb-3 mt-1">Alhamdulillah</div>
                    <h1><span>Get 3 trial</span> sessions before you book</h1>
                    <p>
                        Sign up today to our 3-day free Quran classes to ask questions and to find out about our teaching styles and methods for a unique learning experience!
                    </p>
                    <div class="pt-3 pb-3">

                    </div>
                </div>
                <div style="box-shadow: 10px 10px 52px -20px rgba(0,0,0,0.35);" class="col-lg-6 col-md-6 col-sm-12 m-auto fun-learning-right-heading sm-order-2 order-1">

                        @include('admin.partials.success_message')
                            <form name="contactForm" id='contact_form' class="mb-2 p-3" method="post" action="{{ route('enroll_submit') }}">
                                @csrf
                                <input type="hidden" name="student_time_difference" id="time_zone">
                                <div class="alert alert-danger error_message" style="display:none;" role="alert"></div>
                                <div class="alert alert-success success_message" style="display:none;" role="alert"></div>
                                <div class="field-set">
                                    <label>Enter Your Name</label>
                                    <input type='text' name='name' id='name' class="form-control" placeholder="Your Name" required>
                                    @if($errors->has('name'))
                                    <div class="alert alert-danger" role="alert">{{ $errors->first('name') }}</div>
                                    @endif
                                </div>
                                <div class="field-set">
                                    <label>Enter Your Email</label>
                                    <input type='email' name='email' id='email' class="form-control" placeholder="Your Email" required>
                                    @error('email')
                                    <span class="danger" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>
                                <div class="field-set mb-4">
                                    <label>Your Phone Number</label>
                                    <input type='text' name='phone' id='phone' class="form-control" placeholder="Your Phone" required>
                                    @error('phone')
                                    <span class="danger" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>
                                <div class="field-set mb-4">
                                    @if(config('services.recaptcha.key'))
                                        <div class="g-recaptcha"
                                            data-sitekey="{{config('services.recaptcha.key')}}">
                                        </div>
                                    @endif
                                </div>

                                <div class="text-right">
                                    <img src="{{ asset('images/loading.gif') }}" style="width:50px;" class="loading-image d-none">
                                    <button type='submit' class="btn btn-custom btn-site">Start Free Trial</button>
                                </div>
                            </form>
                </div>

            </div>
        </div>
    </section>


    <section id="section-faq">
        <div class="container">
            <div class="row">
                <div class="col text-center fadeInUp">
                    <h2><span class="uptitle id-color">Read our </span>FAQs</h2>
                    <div class="spacer-20"></div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-10 offset-md-1">
                    <div class="accordion">
                        <div class="accordion-section">
                            @foreach($faqs ?? '' as $faq)
                            <div class="accordion-section-title" data-tab="#accordion-{{ $loop->iteration }}">
                                {{ $faq->question }}
                            </div>
                            <div class="accordion-section-content" id="accordion-{{ $loop->iteration }}">
                                <p>{{ $faq->answer }}</p>
                            </div>
                            @endforeach

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="pt-0 mt-0 pb-5">
        <div class="container-fluid">
            <div class="row">
                <div class="col text-center fadeInUp">
                    <h2><span class="uptitle id-color">Check it out our </span>Testimonials</h2>
                    <div class="spacer-20"></div>
                </div>
            </div>
            <div class="slick-tutors">
                @foreach($videos as $video)

                  <div class="container-thumbnail p-2">
                    <img src="{{asset($video->image)}}" class="image" style="width:100%; height:240px;">
                    <div class="middle">
                      <div class="text youtube-video" data-url="{{$video->url}}"><i class="fas fa-play fa-3x"></i></div>
                    </div>
                  </div>


                @endforeach
            </div>
        </div>
    </section>



    <section id="section-faq" class="bg-light-grey">
        <div class="container">
            <div class="row">
                <div class="col text-center">
                    <h1>Talk to us via whatsapp and get enrolled today</h1>
                    <div class="spacer-20"></div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 text-center">
                    <a href="https://wa.me/+447493320143" class="btn-custom bg-success btn-lg"><i class="fab fa-whatsapp"></i> Call us</a>
                </div>
            </div>
        </div>
    </section>

</div>



<div id="myModal" class="modal fade">
    <div class="modal-dialog modal-md modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">

                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <div class="embed-responsive embed-responsive-16by9">
                    <iframe id="video" class="embed-responsive-item" width="560" height="315"  allowfullscreen></iframe>
                </div>
            </div>
        </div>
    </div>
</div>


@section('js')

<script type="text/javascript">
     $(document).ready(function () {
        var d = new Date();
        var n = d.getTimezoneOffset();
        $('#time_zone').val(n);
     });
    $(document).on('click', '.js-videoPoster', function(e) {
        e.preventDefault();
        var poster = $(this);
        var wrapper = poster.closest('.js-videoWrapper');
        videoPlay(wrapper);
    });

    function videoPlay(wrapper) {
        var iframe = wrapper.find('.js-videoIframe');
        var src = iframe.data('src');

        wrapper.addClass('videoWrapperActive');
        iframe.attr('src', src);
    }
</script>
<script>

function autoType(elementClass, typingSpeed){
  var thhis = $(elementClass);
  thhis.css({
    "position": "relative",
    "display": "inline-block"
  });
  thhis.prepend('<div class="cursor" style="right: initial; left:0;"></div>');
  thhis = thhis.find(".text-js");
  var text = thhis.text().trim().split('');
  var amntOfChars = text.length;
  var newString = "";

  setTimeout(function(){
    thhis.text("");
    for(var i = 0; i < amntOfChars; i++){
      (function(i,char){
        setTimeout(function() {
          newString += char;
          thhis.text(newString);
        },i*typingSpeed);
      })(i+1,text[i]);
    }
  },500);
}

$(document).ready(function(){
    $( ".blinked-circle" ).hide();
  autoType(".type-js",70);
  $( ".blinked-circle" ).delay( 4300 ).fadeIn();
});

  $(document).on('click','a', function(event) {
    if (this.hash !== "") {
      event.preventDefault();
      var hash = this.hash;
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 800, function(){
        window.location.hash = hash;
      });
    }
  });

</script>
<script>
    $(document).ready(function(){

        $('.slick-tutors').slick({
        dots: true,
        infinite: true,
        speed: 300,
        slidesToShow: 4,
        slidesToScroll: 4,
        responsive: [
            {
            breakpoint: 1024,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 3,
                infinite: true,
                dots: true
            }
            },
            {
            breakpoint: 600,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 2
            }
            },
            {
            breakpoint: 480,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1
            }
            }
        ]
        });

    });
    $(document).ready(function() {
        $('.youtube-video').click(function(){
            console.log('stop here pop up');
            let src=$(this).data('url');
            $("#video").attr('src', src);
            $("#myModal").modal('show');
        });
    });
</script>
@endsection
@stop
