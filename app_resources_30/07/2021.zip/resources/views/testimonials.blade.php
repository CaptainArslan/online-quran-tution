@extends('layouts.app')
@section('css')
<style>
    .overlay-gradient{
        background-image: linear-gradient(to right, #fff, #fff); !important;
    }
    .slick-tutors .container-thumbnail {
  position: relative;
  width: 50%;
}

.slick-tutors .image {
  opacity: 1;
  display: block;
  width: 100%;
  height: auto;
  transition: .5s ease;
  backface-visibility: hidden;
}

.slick-tutors .middle {
  transition: .5s ease;
  opacity: 0.9;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  text-align: center;
}

.slick-tutors .container-thumbnail:hover .image {
  opacity: 0.3;
}

.slick-tutors .container-thumbnail:hover .middle {
  opacity: 1;
}

.slick-tutors .text {
  background-color: #3aafa9;
  color: white;
  font-size: 13px;
  padding: 12px 24px;
  cursor: pointer;
}
</style>
@endsection
@section('content')
<!-- content begin -->
<div class="no-bottom no-top" id="content">
    <div id="top"></div>

    <section class="container-banner-lg p-0">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6 col-md-12 col-sm-12 banner-left-heading m-auto">
                    <div class="banner-left-area">
                        <div class="alhamdulillah-dark custom-font-1 mb-3">Alhamdulillah</div>
                        <h1 class="text-dark custom-font-3"><span>Every Review</span> we’ve ever received </h1>
                        <p class="text-justify text-dark">{{ number_format(count($total_testimonials)) }} reviews of parents and students like you</p>
                        <div class="mt-2">
                            <a href="https://uk.trustpilot.com/review/onlinequrantuition.co.uk" target="_blank"><img src="{{ asset('images/trustpilot.png') }}" style="width:140px;" class="img-fluid" alt="Trustpilot"></a>
                            <a href="https://bit.ly/37tlXz8" class="ml-3" target="_blank"><img src="{{ asset('images/google.png') }}" style="width:140px;" class="img-fluid" alt="Google Reviews"></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 asideimg" style="background-image: linear-gradient(0deg, rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url({{ asset('images/bg-3.jpg') }});"></div>
                {{-- <div class="col-lg-6 col-md-6 col-sm-12 asideimg" style="background-image: url({{ asset('images/bg-3.jpg') }});">

                </div> --}}
            </div>
        </div>
    </section>
    <section class="container-banner-md p-0" style="background-image: linear-gradient(0deg, rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url({{ asset('images/bg-3.jpg') }});">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-12 col-sm-12 banner-left-heading m-auto">
                    <div class="banner-left-area">
                        <div class="alhamdulillah-white custom-font-1 mb-3">Alhamdulillah</div>
                        <h1 class="text-white custom-font-3"><span>Every Review</span> we’ve ever received </h1>
                        <p class="text-justify text-white">{{ number_format(count($testimonials)) }} reviews from hundreds of parents and students like you</p>
                        <div class="mt-2">
                            <a href="https://uk.trustpilot.com/review/onlinequrantuition.co.uk" target="_blank"><img src="{{ asset('images/trustpilot.png') }}" style="width:140px;" class="img-fluid" alt="Trustpilot"></a>
                            <a href="https://bit.ly/37tlXz8" class="ml-3" target="_blank"><img src="{{ asset('images/google.png') }}" style="width:140px;" class="img-fluid" alt="Google Reviews"></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-12"></div>
                {{-- <div class="col-lg-6 col-md-6 col-sm-12 asideimg" style="background-image: url({{ asset($settings['header_banner_image']) }});">

                </div> --}}
            </div>
        </div>
    </section>



    <section class="reviews pt-3">
        <div class="container">
            <!--reviews collection data-->
            <div class="row mb-3">
                <div class="col-md-8 col-sm-6 m-auto">
                    <h2>Every review we've ever received</h2>
                </div>
                <div class="col-md-4 col-sm-6">
                    <div class="media">
                        <div class="p-3 text-center m-auto">
                            <h1>{{ round($avg,2) ?? 0 }}</h1>
                            <h4>out of 5 ({{ number_format(count($total_testimonials)) ?? 0 }})</h4>
                        </div>
                        <div class="media-body m-auto">
                            <div>
                                <table class="w-100">
                                    <tr>
                                        <td width="10%"><i class="fa fa-star"></i></td>
                                        <td>5</td>
                                        <td width="50%">
                                            <span class="progress">
                                                <span class="progress-bar" role="progressbar" style="width: {{ count($testimonials) > 0 ? $star5 / count($testimonials) * 100 : '0' }}%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></span>
                                            </span>
                                        </td>
                                        <td>{{ number_format($star5) ?? 0 }}</td>
                                    </tr>

                                    <tr>
                                        <td width="10%"><i class="fa fa-star"></i></td>
                                        <td>4</td>
                                        <td width="50%">
                                            <span class="progress">
                                                <span class="progress-bar" role="progressbar" style="width: {{ count($testimonials) > 0 ? $star4 / count($testimonials) * 100 : '0' }}%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></span>
                                            </span>
                                        </td>
                                        <td>{{ number_format($star4) ?? 0 }}</td>
                                    </tr>
                                    <tr>
                                        <td width="10%"><i class="fa fa-star"></i></td>
                                        <td>3</td>
                                        <td width="50%">
                                            <span class="progress">
                                                <span class="progress-bar" role="progressbar" style="width: {{ count($testimonials) > 0 ? $star3 / count($testimonials) * 100 : '0' }}%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></span>
                                            </span>
                                        </td>
                                        <td>{{ number_format($star3) ?? 0 }}</td>
                                    </tr>
                                    <tr>
                                        <td width="10%"><i class="fa fa-star"></i></td>
                                        <td>2</td>
                                        <td width="50%">
                                            <span class="progress">
                                                <span class="progress-bar" role="progressbar" style="width: {{ count($testimonials) > 0 ? $star2 / count($testimonials) * 100 : '0' }}%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></span>
                                            </span>
                                        </td>
                                        <td>{{ number_format($star2) ?? 0 }}</td>
                                    </tr>
                                    <tr>
                                        <td width="10%"><i class="fa fa-star"></i></td>
                                        <td>1</td>
                                        <td width="50%">
                                            <span class="progress">
                                                <span class="progress-bar" role="progressbar" style="width: {{ count($testimonials) > 0 ? $star1 / count($testimonials) * 100 : '0' }}%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></span>
                                            </span>
                                        </td>
                                        <td>{{ number_format($star1) ?? 0 }}</td>
                                    </tr>
                                </table>

                            </div>
                        </div>
                      </div>
                </div>
            </div>
            <!--reviews collection data-->
            @foreach ($testimonials as $item)
            <div class="row row-serial mb-4">
                <div class="col-md-2 col-sm-12"></div>
                <div class="col-md-8 col-sm-12 testimonial-description">
                    {{-- <h3>Jane <span>Parent from <a href="">Rockstar</a> </span></h3> --}}
                    <h3>{{ $item->name }}</h3>
                    <p>
                        {{ $item->review }}
                    </p>

                    <div class="clear-fix">
                        <div class="float-left rating-stars">
                            @for ($i = 0; $i < 5; $i++)
                                @if (floor($item->rating) - $i >= 1)
                                    {{--Full Star--}}
                                    <i class="fa fa-star"></i>
                                @elseif ($item->rating - $i > 0)
                                    {{--Half Star--}}
                                    <i class="fa fa-star-half-o"></i>
                                @else
                                    {{--Empty Star--}}
                                    <i class="fa fa-star-o"></i>
                                @endif
                            @endfor
                        </div>
                    </div>
                    <div class="float-right">
                        <strong>{{ \Carbon\Carbon::parse($item->review_date)->format('M d, Y') }}</strong>
                    </div>
                </div>
                <div class="col-md-2 col-sm-12"></div>
            </div>
            @endforeach
            <div class="row mt-3">
                <div class="col-md-3"></div>
                <div class="col-md-6 justify-content-center">
                    {{ $testimonials->links() }}
                </div>
                <div class="col-md-3"></div>
            </div>
        </div>
    </section>

    <section id="section-testimonial" class="no-top no-bottom text-light pt-0 mt-0 bg-white" data-bgimage="center" data-stellar-background-ratio=".1">
        <div class="overlay-gradient bg-white">
            <div class="text-center ">
                <h2 class="text-dark">{{ $settings['testimonial_heading'] ?? '' }}</h2>
                {{-- {{ $settings['testimonial_description'] ?? '' }} --}}
                <div class="spacer-20"></div>
            </div>
           <div class="slick-tutors">
                @foreach($videos as $video)

                  <div class="container-thumbnail p-2">
                    <img src="{{asset($video->image)}}" class="image" style="width:100%; height:240px;">
                    <div class="middle">
                      <div class="text youtube-video" data-url="{{$video->url}}"><i class="fas fa-play fa-3x"></i></div>
                    </div>
                  </div>


                @endforeach
            </div>
        </div>
    </section>

    <section class="section-handpicked pt-3 pb-3" id="inquiry-form">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 m-auto handpicked-right-heading">
                    <h1><span>Are you interested?</span> Sign up for 3-day FREE trial today</h1>
                </div>
                <div style="box-shadow: 10px 10px 52px -20px rgba(0,0,0,0.35);" class="col-lg-6 col-md-6 col-sm-12 m-auto fun-learning-right-heading">

                        @include('admin.partials.success_message')
                            <form name="contactForm" id='contact_form' class="mb-2 p-3" method="post" action="{{ route('enroll_submit') }}">
                                @csrf
                                <input type="hidden" name="student_time_difference" id="time_zone">
                                @if($errors->has('name'))
                                <div class="alert alert-danger" role="alert">{{ $errors->first('name') }}</div>
                                @endif
                                <div class="field-set">
                                    <label>Enter Your Name</label>
                                    <input type='text' name='name' id='name' class="form-control" placeholder="Your Name">
                                    @if($errors->has('name'))
                                    <div class="alert alert-danger" role="alert">{{ $errors->first('name') }}</div>
                                    @endif
                                </div>
                                <div class="field-set">
                                    <label>Enter Your Email</label>
                                    <input type='text' name='email' id='email' class="form-control" placeholder="Your Email">
                                    @error('email')
                                    <span class="danger" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>
                                <div class="field-set">
                                    <label>Your Phone Number</label>
                                    <input type='text' name='phone' id='phone' class="form-control" placeholder="Your Phone">
                                    @error('phone')
                                    <span class="danger" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>
                                <div class="field-set mb-4">
                                    @if(config('services.recaptcha.key'))
                                        <div class="g-recaptcha"
                                            data-sitekey="{{config('services.recaptcha.key')}}">
                                        </div>
                                    @endif
                                </div>

                                <div class="text-center">
                                    <button type='submit' class="btn btn-custom btn-site">Start Free Trial</button>
                                </div>
                            </form>
                </div>

            </div>
        </div>
    </section>

    <section id="section-faq" class="bg-white">
        <div class="container">
            <div class="row">
                <div class="col text-center ">
                    <h1>Got a question? Call us to ask about our service and how we can assist you.</h1>
                    <div class="spacer-20"></div>
                </div>
            </div>
            <div class="row ">
                <div class="col-md-12 text-center">
                    <a href="" class="btn-custom bg-success btn-lg"><i class="fa fa-whatsapp"></i> Call us</a>
                </div>
            </div>
        </div>
    </section>

   
    <div id="myModal" class="modal fade">
    <div class="modal-dialog modal-md modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">

                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <div class="embed-responsive embed-responsive-16by9">
                    <iframe id="video" class="embed-responsive-item" width="560" height="315"  allowfullscreen></iframe>
                </div>
            </div>
        </div>
    </div>
</div>
   
   
<!-- section close -->
</div>
@section('js')

    <script>
    $(document).ready(function () {
        var d = new Date();
        var n = d.getTimezoneOffset();
        $('#time_zone').val(n);
     });
        $(document).on('click', '.js-videoPoster', function(e) {
        e.preventDefault();
        var poster = $(this);
        var wrapper = poster.closest('.js-videoWrapper');
        videoPlay(wrapper);
    });

    function videoPlay(wrapper) {
        var iframe = wrapper.find('.js-videoIframe');
        var src = iframe.data('src');

        wrapper.addClass('videoWrapperActive');
        iframe.attr('src', src);
    }
    </script>
    <script>
    $(document).ready(function(){

        $('.slick-tutors').slick({
        dots: true,
        infinite: true,
        speed: 300,
        slidesToShow: 4,
        slidesToScroll: 4,
        responsive: [
            {
            breakpoint: 1024,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 3,
                infinite: true,
                dots: true
            }
            },
            {
            breakpoint: 600,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 2
            }
            },
            {
            breakpoint: 480,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1
            }
            }
        ]
        });

    });
    $(document).ready(function() {
        $('.youtube-video').click(function(){
            console.log('stop here pop up');
            let src=$(this).data('url');
            $("#video").attr('src', src);
            $("#myModal").modal('show');
        });
    });
</script>

<script>

function autoType(elementClass, typingSpeed){
  var thhis = $(elementClass);
  thhis.css({
    "position": "relative",
    "display": "inline-block"
  });
  thhis.prepend('<div class="cursor" style="right: initial; left:0;"></div>');
  thhis = thhis.find(".text-js");
  var text = thhis.text().trim().split('');
  var amntOfChars = text.length;
  var newString = "";

  setTimeout(function(){
    thhis.text("");
    for(var i = 0; i < amntOfChars; i++){
      (function(i,char){
        setTimeout(function() {
          newString += char;
          thhis.text(newString);
        },i*typingSpeed);
      })(i+1,text[i]);
    }
  },500);
}

$(document).ready(function(){
    $( ".blinked-circle" ).hide();
  autoType(".type-js",70);
  $( ".blinked-circle" ).delay( 4300 ).fadeIn();
});

  $(document).on('click','a', function(event) {
    if (this.hash !== "") {
      event.preventDefault();
      var hash = this.hash;
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 800, function(){
        window.location.hash = hash;
      });
    }
  });

</script>


@endsection
@stop
