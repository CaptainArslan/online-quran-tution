@extends('layouts.app')
@section('content')

<div class="no-bottom no-top" id="content">
    <div id="top"></div>
    <!-- revolution slider begin -->
    <!-- section begin -->
    <section class="no-top no-bottom text-light" data-bgimage="url({{asset('front_assets')}}/images/background/6.jpg" ) data-stellar-background-ratio=".2">
        <div class="overlay-gradient t80 pb30 pt90">
            <div class="center-y pt30 ">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-8 offset-md-2 text-center">
                            <h1>For Email Verify</h1>
                            <p class="lead">Ask any questions using form below.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="relative no-top no-bottom " data-bgimage="" data-stellar-background-ratio=".2">

        <div class="mt30">
            <div class="center-y">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="">
                            <h1>Please Verify Your Email Address</h1>
                        </div>
                        <div>
                            <h3>
                                {{ __('Before proceeding, please check your email for a verification link.') }}
                                {{ __('If you did not receive the email') }},
                                <form class="d-inline" method="POST" action="{{ route('verification.resend') }}">
                                    @csrf
                                    <button type="submit" class="btn btn-link p-0 m-0 align-baseline">{{ __('click here to request another') }}</button>.
                                </form>
                            </h3>
                            <h4>
                                @if (session('resent'))
                                <div class="alert alert-success" role="alert">
                                    {{ __('A fresh verification link has been sent to your email address.') }}
                                </div>
                                @endif
                            </h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>
    <!-- section close -->

</div>

@endsection