

@extends('layouts.app')
@section('title', 'Login')
@section('content')
<!-- content begin -->
<div class="no-bottom no-top" id="content">
    <div id="top"></div>

    <section class="container-banner-lg p-0">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6 col-md-12 col-sm-12 banner-left-heading m-auto">
                    <div class="banner-left-area">
                        <h1 class="text-dark custom-font-3"><span>Correct credentials,</span> take you to dashboard</h1>
                        <p class="text-justify text-dark">Login to experience the best tutor service in the world.</p>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 asideimg" style="background-image: linear-gradient(0deg, rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url({{ asset($settings['header_banner_image']) }});"></div>
                {{-- <div class="col-lg-6 col-md-6 col-sm-12 asideimg" style="background-image: url({{ asset($settings['header_banner_image']) }});">

                </div> --}}
            </div>
        </div>
    </section>
    <section class="container-banner-md p-0" style="background-image: linear-gradient(0deg, rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url({{ asset($settings['header_banner_image']) }});">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-12 col-sm-12 banner-left-heading m-auto">
                    <div class="banner-left-area">
                        <h1 class="text-white custom-font-3"><span>Correct credentials,</span> take you to dashboard</h1>
                        <p class="text-justify text-white">Login to experience the best tutor service in the world.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-12"></div>
                {{-- <div class="col-lg-6 col-md-6 col-sm-12 asideimg" style="background-image: url({{ asset($settings['header_banner_image']) }});">

                </div> --}}
            </div>
        </div>
    </section>

    <section class="relative no-top no-bottom " data-bgimage="" data-stellar-background-ratio=".2">
        <div class="mt30">
            <div class="center-y">
                <div class="container">
                    <div class="row">
                        <div class="col-12 banner-left-heading text-center">
                            <h2>Login your account</h2>
                        </div>
                    </div>
                    <div class="row">
                        @include('admin.partials.success_message')
                    </div>
                    <div class="row mb-4">
                        <div class="col-lg-3"></div>
                        <div class="col-lg-6 mb-sm-30" style="box-shadow: 10px 10px 52px -20px rgba(0,0,0,0.35);">
                            <form name="contactForm" id='' class=" p-4" method="post" action="{{ route('admin/login') }}">
                                @csrf
                                @include('admin.partials.success_message')
                                <div class="field-set">
                                    <label>Enter Your Email</label>
                                    <input type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" id="email" autocomplete="email" autofocus placeholder="Email" required>
                                    @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>

                                <div class="field-set">
                                    <label>Enter Your Password</label>
                                    <input type="password" class="form-control @error('password') is-invalid @enderror" name="password" autocomplete="current-password" id="name" placeholder="Password" required>
                                    @error('password')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>

                                <div class="spacer-half"></div>

                                <div id='submit'>
                                    <button type='submit' class="btn btn-site">Login</button>
                                    <div class="text-left">
                                        @if (Route::has('password.request'))
                                        <a class="card-link" href="{{ route('password.request') }}">
                                            {{ __('Forgot Your Password?') }}
                                        </a>
                                    </div>
                                    @endif


                                </div>
                                <div id='mail_success' class='success'>Your message has been sent successfully.</div>
                                <div id='mail_fail' class='error'>Sorry, error occured this time sending your message.</div>

                            </form>
                        </div>
                        <div class="col-lg-3"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>




</div>
<!-- content close -->


@stop

@section('js')
    <script>
        $(window).load(function() {
            jQuery('html,body').animate({scrollTop:380});

});
    </script>
@endsection
