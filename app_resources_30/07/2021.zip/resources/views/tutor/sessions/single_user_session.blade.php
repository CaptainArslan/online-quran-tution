@extends("tutor.layouts.app")
@section('css')
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.20/jquery.datetimepicker.css">
{{-- claender css --}}
<link rel="stylesheet" type="text/css" href="{{asset('admin_theme')}}/app-assets/vendors/css/vendors.min.css">
<link rel="stylesheet" type="text/css" href="{{asset('admin_theme')}}/app-assets/vendors/css/calendars/fullcalendar.min.css">
<link rel="stylesheet" type="text/css" href="{{asset('admin_theme')}}/app-assets/vendors/css/calendars/extensions/daygrid.min.css">
<link rel="stylesheet" type="text/css" href="{{asset('admin_theme')}}/app-assets/vendors/css/calendars/extensions/timegrid.min.css">
<link rel="stylesheet" type="text/css" href="{{asset('admin_theme')}}/app-assets/vendors/css/pickers/pickadate/pickadate.css">
<link rel="stylesheet" type="text/css" href="{{asset('admin_theme')}}/app-assets/css/core/menu/menu-types/horizontal-menu.css">
<link rel="stylesheet" type="text/css" href="{{asset('admin_theme')}}/app-assets/css/core/colors/palette-gradient.css">
<link rel="stylesheet" type="text/css" href="{{asset('admin_theme')}}/app-assets/css/plugins/calendars/fullcalendar.css">
  <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" id="theme-styles">

<style>
  .fc-content .fc-time {
    font-size: 24px !important;
    text-align: center !important;
    color: white;
    font-weight: bold;
  }
</style>
@endsection
@section('content')
@include('admin.partials.success_message')
@section('topbar-heading', 'Session')
    
    
<!-- 
    <div class="col-md-12 mb-2 text-right">
        <a href="{{route('tutor.edit.schedule',$id)}}" class="btn btn-primary ">Edit Schedule</a>
    </div>
 -->
<div class="col-md-12 p-0">
    <div class="card">
        <div class="card-body">
            <table class="table dataTable">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Day</th>
                    <th>Time</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>

                @foreach($schedules as $schedule)
                    @php
                        if ($schedule->day==1)
                            $day='Monday';
                        elseif($schedule->day==2)
                            $day='Tuesday';
                        elseif($schedule->day==3)
                            $day='Wednesday';
                        elseif($schedule->day==4)
                            $day='Thursday';
                        elseif($schedule->day==5)
                            $day='Friday';
                        elseif($schedule->day==6)
                            $day='Saturday';
                        elseif($schedule->day==7)
                            $day='Sunday';
                    @endphp
                    <tr>
                        <td>{{$loop->iteration}}</td>
                        <td>{{$day}}</td>
                        <td><span class="badge badge-dark">{{$schedule->time}}</span></td>
                        <td>
                            <button  class="btn btn-primary @if($trial_payment == false) cannot-start @else start-session @endif" type="button">Start</button>
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>


<!-- Full calendar start -->
<section id="basic-examples">
  <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-content">
                    <div class="card-body">

                          <div  class="text-center">
                            <h5>Student Information</h5>
                          </div>

                        <ul class="list-group">
                          <li class="list-group-item d-flex justify-content-between align-items-center">
                              <h5>Name:</h5>
                              <h5><span class="text-primary">{{ $std->name ?? 'N/A' }}</h5>

                          </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                              <h5>Contact:</h5>
                              <a href="{{ route('messenger', $std->id ?? '' ) }}" target="_blank" class="btn btn-success">Send a message</a>
                          </li>

                        </ul>

                    </div>
                </div>
            </div>
        </div>
    </div>
  <div class="row">
    <div class="col-12">
      <div class="card">
        <div class="card-content">
          <div class="card-body">
            <div id='fc-default'></div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- calendar Modal starts-->
  <div class="modal fade text-left modal-calendar" tabindex="-1" role="dialog" aria-labelledby="cal-modal" aria-modal="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-sm" role="document">
      <div class="modal-content">
        <button type="button" class="close text-right pb-0" style="font-size: 25px;padding-right: 4px;" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
        <div class="modal-body pt-0">
          <div class="text-cetner">
            <button class="btn-block btn btn-success font-weight-bold p-1" id="btnSessionStart">Start your Scheduled Session</button>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- calendar Modal ends-->
</section>
<!-- // Full calendar end -->
@section('js')

<script src="{{asset('admin_theme')}}/app-assets/vendors/js/extensions/moment.min.js"></script>
<script src="{{asset('admin_theme')}}/app-assets/vendors/js/calendar/fullcalendar.min.js"></script>
<script src="{{asset('admin_theme')}}/app-assets/vendors/js/ui/jquery.sticky.js"></script>
<script src="{{asset('admin_theme')}}/app-assets/vendors/js/calendar/extensions/daygrid.min.js"></script>
<script src="{{asset('admin_theme')}}/app-assets/vendors/js/calendar/extensions/timegrid.min.js"></script>
<script src="{{asset('admin_theme')}}/app-assets/vendors/js/calendar/extensions/interactions.min.js"></script>
<script src="{{asset('admin_theme')}}/app-assets/vendors/js/pickers/pickadate/picker.js"></script>
<script src="{{asset('admin_theme')}}/app-assets/vendors/js/pickers/pickadate/picker.date.js"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.js"></script>
{{-- <script src="{{asset('admin_theme')}}/app-assets/js/scripts/extensions/fullcalendar-custom.js"></script> --}}
<script>
    $(document).ready(function(){
       $('.cannot-start').click(function(){
           Swal.fire({
              icon: 'error',
              title: 'Oops...',
              text: 'Cannot Start class untill student pay for the class!',
              
            })
       }) ;
    });

  document.addEventListener('DOMContentLoaded', function() {
    // color object for different event types
    var colors = {
      primary: "#7367f0",
      success: "#28c76f",
      danger: "#ea5455",
      warning: "#ff9f43"
    };

    // chip text object for different event types
    var categoryText = {
      primary: "Others",
      success: "Business",
      danger: "Personal",
      warning: "Work"
    };
    var categoryBullets = $(".cal-category-bullets").html(),
      evtColor = "",
      eventColor = "";

    // calendar init
    var calendarEl = document.getElementById('fc-default');

    var calendar = new FullCalendar.Calendar(calendarEl, {
      plugins: ["timeGrid", "interaction"],
      customButtons: {
        addNew: {
          text: ' Add',
          click: function() {
            var calDate = new Date,
              todaysDate = calDate.toISOString().slice(0, 10);
            $(".modal-calendar").modal("show");
            $(".modal-calendar .cal-submit-event").addClass("d-none");
            $(".modal-calendar .remove-event").addClass("d-none");
            $(".modal-calendar .cal-add-event").removeClass("d-none")
            $(".modal-calendar .cancel-event").removeClass("d-none")
            $(".modal-calendar .add-category .chip").remove();
            $("#cal-start-date").val(todaysDate);
            $("#cal-end-date").val(todaysDate);
            $(".modal-calendar #cal-start-date").attr("disabled", false);
          }
        }
      },


      header: {
        left: "",
        center: "",
        right: "prev,title,next"
      },
      displayEventTime: true,
      navLinks: true,
      editable: true,
      allDay: true,
      events: <?php echo json_encode($Events); ?>,
      navLinkDayClick: function(date) {
        $(".modal-calendar").modal("show");
      },


      dateClick: function(info) {
        //$(".modal-calendar #cal-start-date").val(info.dateStr).attr("disabled", true);
        //$(".modal-calendar #cal-end-date").val(info.dateStr);
      },
      // displays saved event values on click
      eventClick: function(info) {
        $(".modal-calendar").modal("show");
        $(".modal-calendar #cal-event-title").val(info.event.title);
        $(".modal-calendar #cal-start-date").val(moment(info.event.start).format('YYYY-MM-DD'));
        $(".modal-calendar #cal-end-date").val(moment(info.event.end).format('YYYY-MM-DD'));
        $(".modal-calendar #cal-description").attr("href", info.event.extendedProps.description);
        $(".modal-calendar .cal-submit-event").removeClass("d-none");
        $(".modal-calendar .remove-event").removeClass("d-none");
        $(".modal-calendar .cal-add-event").addClass("d-none");
        $(".modal-calendar .cancel-event").addClass("d-none");
        $(".calendar-dropdown .dropdown-menu").find(".selected").removeClass("selected");
        var eventCategory = info.event.extendedProps.dataEventColor;
        var eventText = categoryText[eventCategory]
        $(".modal-calendar .chip-wrapper .chip").remove();
        $(".modal-calendar .chip-wrapper").append($("<div class='chip chip-" + eventCategory + "'>" +
          "<div class='chip-body'>" +
          "<span class='chip-text'> " + eventText + " </span>" +
          "</div>" +
          "</div>"));
      },
    });

    // render calendar
    calendar.render();

    // appends bullets to left class of header
    $("#basic-examples .fc-right").append(categoryBullets);

    // Close modal on submit button
    $(".modal-calendar .cal-submit-event").on("click", function() {
      $(".modal-calendar").modal("hide");
    });

    // Remove Event
    $(".remove-event").on("click", function() {
      var removeEvent = calendar.getEventById('newEvent');
      removeEvent.remove();
    });


    // reset input element's value for new event
    if ($("td:not(.fc-event-container)").length > 0) {
      $(".modal-calendar").on('hidden.bs.modal', function(e) {
        $('.modal-calendar .form-control').val('');
      })
    }

    // remove disabled attr from button after entering info
    $(".modal-calendar .form-control").on("keyup", function() {
      if ($(".modal-calendar #cal-event-title").val().length >= 1) {
        $(".modal-calendar .modal-footer .btn").removeAttr("disabled");
      } else {
        $(".modal-calendar .modal-footer .btn").attr("disabled", true);
      }
    });

    // open add event modal on click of day
    $(document).on("click", ".fc-day", function() {
      $(".modal-calendar").modal("show");
      $(".calendar-dropdown .dropdown-menu").find(".selected").removeClass("selected");
      $(".modal-calendar .cal-submit-event").addClass("d-none");
      $(".modal-calendar .remove-event").addClass("d-none");
      $(".modal-calendar .cal-add-event").removeClass("d-none");
      $(".modal-calendar .cancel-event").removeClass("d-none");
      $(".modal-calendar .add-category .chip").remove();
      $(".modal-calendar .modal-footer .btn").attr("disabled", true);
      evtColor = colors.primary;
      eventColor = "primary";
    });

    // change chip's and event's color according to event type
    $(".calendar-dropdown .dropdown-menu .dropdown-item").on("click", function() {
      var selectedColor = $(this).data("color");
      evtColor = colors[selectedColor];
      eventTag = categoryText[selectedColor];
      eventColor = selectedColor;

      // changes event color after selecting category
      $(".cal-add-event").on("click", function() {
        calendar.addEvent({
          color: evtColor,
          dataEventColor: eventColor,
          className: eventColor
        });
      })

      $(".calendar-dropdown .dropdown-menu").find(".selected").removeClass("selected");
      $(this).addClass("selected");

      // add chip according to category
      $(".modal-calendar .chip-wrapper .chip").remove();
      $(".modal-calendar .chip-wrapper").append($("<div class='chip chip-" + selectedColor + "'>" +
        "<div class='chip-body'>" +
        "<span class='chip-text'> " + eventTag + " </span>" +
        "</div>" +
        "</div>"));
    });

    // calendar add event
    $(".cal-add-event").on("click", function() {
      $(".modal-calendar").modal("hide");
      var eventTitle = $("#cal-event-title").val(),
        startDate = $("#cal-start-date").val(),
        endDate = $("#cal-end-date").val(),
        eventDescription = $("#cal-description").val(),
        correctEndDate = new Date(endDate);
      calendar.addEvent({
        id: "newEvent",
        title: eventTitle,
        start: startDate,
        end: correctEndDate,
        description: eventDescription,
        color: evtColor,
        dataEventColor: eventColor,
        allDay: true
      });
    });

    // date picker
    $(".pickadate").pickadate({
      format: 'yyyy-mm-dd'
    });
  });
</script>

<script>
  $("#btnSessionStart").click(function() {
    $(this).html('Creating Session...');



    $.ajaxSetup({
      headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
      }
    });

    $.ajax({
      type: "POST",
      url: "{{ route('tutor.session_create') }}",
      data: {
        inquiry_id:{{$id}},
      }
    }).done(function(data) {
      console.log(data.msg);
      
      if(data.code == 400)
      {
          toastr.error(data.msg);
          $('#btnSessionStart').html('Start your scheduled session');
        $(".modal-calendar").modal("hide");
      }
      else
      {
        window.location.href = data.msg;
      }
      

    });

  });
</script>
    <script>
        $(document).ready(function () {

            $('.start-session').click(function () {
                $(".modal-calendar").modal("show");
            });

        });
    </script>

@endsection
@stop
