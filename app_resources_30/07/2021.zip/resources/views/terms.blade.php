@extends('layouts.app')
@section('title', $settings['how_it_works_meta_title'] ?? '')
@section('meta')

<meta name="description" content="{{ $settings['how_it_works_meta_description'] ?? '' }}">
<meta name="keywords" content="{{ $settings['how_it_works_meta_keywords'] ?? '' }}">
@endsection
@section('content')
<!-- content begin -->
<div class="no-bottom no-top" id="content">
    <div id="top"></div>

    <section class="container-banner-lg p-0">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6 col-md-12 col-sm-12 banner-left-heading m-auto">
                    <div class="banner-left-area">
                        <h1 class="text-dark custom-font-3">Terms & <span>Laws</span></h1>
                        <p class="text-justify text-dark">By using our site you accept these terms and conditions.</p>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 asideimg" style="background-image: linear-gradient(0deg, rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url({{ asset($settings['header_banner_image']) }});"></div>
                {{-- <div class="col-lg-6 col-md-6 col-sm-12 asideimg" style="background-image: url({{ asset($settings['header_banner_image']) }});">

                </div> --}}
            </div>
        </div>
    </section>
    <section class="container-banner-md p-0" style="background-image: linear-gradient(0deg, rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url({{ asset($settings['header_banner_image']) }});">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-12 col-sm-12 banner-left-heading m-auto">
                    <div class="banner-left-area">
                        <h1 class="text-white custom-font-3">Terms & <span>Laws</span></h1>
                        <p class="text-justify text-white">By using our site you accept these terms and conditions.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-12"></div>
                {{-- <div class="col-lg-6 col-md-6 col-sm-12 asideimg" style="background-image: url({{ asset($settings['header_banner_image']) }});">

                </div> --}}
            </div>
        </div>
    </section>

    <section class="p-0" id="free-members">
        <div class="container">
            <div class="card mt-4 mb-4 schools-card">
                <div class="card-header p-0 text-center schoools-card-heading">
                    <h2 class="pt-1 m-0">License Free Terms & Conditions</h2>
                </div>
                <div class="card-body">
                    <h4 class="alert alert-warning">IMPORTANT NOTICE: This license only applies if you downloaded this content as
                        an unsubscribed user. If you are a premium user (ie, you pay a subscription)
                        you are bound to the license terms described in the section <a href="#premium-members">"Premium Member Terms & Conditions"</a></h4>
                    <h4>You must attribute the image to its author:</h4>
                    <p>In order to use a content or a part of it, you must attribute it to slidesgo / Freepik,
                        so we will be able to continue creating new graphic resources every day.</p>

                        <h4>How to attribute it?</h4>
                        <p><em>For websites:</em> Please, copy this code on your website to accredit the author:
                            <a href="http://www.freepik.com">Designed by slidesgo / Freepik</a></p>

                        <p><em>For printing:</em> Paste this text on the final work so the authorship is known.
                            - For example, in the acknowledgements chapter of a book:
                            "Designed by slidesgo / Freepik"</p>

                    <h4>You are free to use this image:</h4>
                    <p>- For both personal and commercial projects and to modify it.</p>
                    <p>- In a website or presentation template or application or as part of your design.</p>

                    <h4>You are not allowed to:</h4>
                    <p>- Sub-license, resell or rent it.</p>
                    <p>- Include it in any online or offline archive or database.</p>

                    <h4>The full terms of the license are described in section 7 of the Freepik
                        terms of use, available online in the following link:</h4>

                        <p><a href="http://www.freepik.com/terms_of_use">http://www.freepik.com/terms_of_use</a></p>
                        <p>The terms described in the above link have precedence over the terms described
                            in the present document. In case of disagreement, the Freepik Terms of Use
                            will prevail.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="p-0" id="premium-members">
        <div class="container">
            <div class="card mt-2 mb-4 schools-card">
                <div class="card-header p-0 text-center schoools-card-heading">
                    <h2 class="pt-1 m-0">Premium Member Terms & Conditions</h2>
                </div>
                <div class="card-body">
                    <h4 class="alert alert-warning">IMPORTANT NOTICE: This license only applies if you downloaded this content as
                        a subscribed (or "premium") user. If you are an unsubscribed user (or "free"
                        user) you are bound to the license terms described in the section <a href="#free-members">"License Free Terms & Conditions"</a></h4>
                    <h4>You can download from your profile in Freepik a personalized license stating
                        your right to use this content as a "premium" user:</h4>
                    <p><a href="https://profile.freepik.com/my_downloads">https://profile.freepik.com/my_downloads</a></p>

                        <h4>You are free to use this image:</h4>
                        <p>- For both personal and commercial projects and to modify it.</p>
                        <p>- In a website or presentation template or application or as part of your design.</p>


                    <h4>You are not allowed to:</h4>
                    <p>- Sub-license, resell or rent it.</p>
                    <p>- Include it in any online or offline archive or database.</p>

                    <h4>The full terms of the license are described in sections 7 and 8 of the Freepik
                        terms of use, available online in the following link:</h4>
                    <p><a href="http://www.freepik.com/terms_of_use">http://www.freepik.com/terms_of_use</a></p>

                    <p>The terms described in the above link have precedence over the terms described
                        in the present document. In case of disagreement, the Freepik Terms of Use
                            will prevail.</p>
                </div>
            </div>
        </div>
    </section>


</div>
<!-- content close -->

@stop
