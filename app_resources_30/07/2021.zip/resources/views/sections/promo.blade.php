<div class="col-sm-12 mb-2">
    <a class="font-weight-bold text-secondary" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample"><u>Have a promo code?</u></a>
      <div class="collapse" id="collapseExample">
        <label class="text-danger" id="response-msg"></label>
            <div class="input-group">
              <input type="text" class="form-control" id="promo" name="promo" placeholder="promo code e.g. MBL350" onkeyup="this.value = this.value.toUpperCase();">
              <div class="input-group-prepend">
                <button type="button" class="btn btn-info input-group-text apply-coupan-btn">Apply</button>
              </div>
            </div>
      </div>
</div>
