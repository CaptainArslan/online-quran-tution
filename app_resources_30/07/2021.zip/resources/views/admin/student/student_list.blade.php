@extends('admin.layouts.app')
@section('title', 'List of Student')

@section('content')
<div class="col-12">
  @if(session()->has('message'))
  <div class="alert alert-success">
    {{ session()->get('message') }}
  </div>
  @endif
</div>
<div class="row">
  <div class="col-md-12">
    <div class="card">
      <div class="card-header card-header-primary">
        <h4 class="card-title ">Student(s)</h4>
        <div class="pull-right">
          <form method="GET" action="{{route('admin.studen_list')}}" class="filter-form">
            <button type="submit" name="export" value="export" class="btn btn-info btn-block">Export</button>
          </form>
        </div>
      </div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered table-striped datatable">
            <thead>
              <tr>
                <th>
                  ID
                </th>
                <th>
                  Name
                </th>
                <th>
                  Email
                </th>
                <th>
                  phone
                </th>
                <th>Member Since</th>
                
                <th>
                  Action
                </th>
        {{--        @if(auth()->user()->role==="admin")
                <th>
                  Payouts
                </th>
                @endif --}}
              </tr>
            </thead>
            <tbody>
              @foreach ($data as $st)
                @if($st->user == null)
                    
                  @continue;
                @endif
              <tr>
                <td>
                  {{ $loop->iteration }}
                </td>
                <td>
                  {{$st->user->name?? ''}}
                </td>
                <td>
                  {{$st->user->email?? ''}}
                </td>
                <td>
                  {{$st->user->phone?? ''}}
                </td>
                <th>{{date('d/m/Y',strtotime($st->created_at))}}</th>
               
                <td class="btn-group">
                    <a href="{{route('admin.student.inquiry.detail',$st->id)}}" class="btn btn-primary">Detail</a>
{{--                    <a href="{{route('admin.student.edit.schedule',$st->id)}}" class="btn btn-primary" title="Edit Schedule"><i class="fa fa-edit"></i> </a>--}}
                  <button class="btn btn-danger m-0 btn-block" onclick="deleteAlert('{{route('admin.student_delete',['id'=>$st->user->id])}}')" style="margin-left:10px">Delete</button>
                </td>
        {{--         @if(auth()->user()->role==="admin")
                <td>
                  <a href="{{ route('admin.student.payouts', $st->user->id) }}" class="btn btn-info btn-block">Paid Payments</a>
                </td>
                @endif  --}}
              </tr>
              @endforeach
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
@stop
