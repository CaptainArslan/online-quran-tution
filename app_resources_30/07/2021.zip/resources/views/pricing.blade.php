@extends('layouts.app')
@section('title', $settings['how_it_works_meta_title'] ?? '')
@section('meta')

<meta name="description" content="{{ $settings['how_it_works_meta_description'] ?? '' }}">
<meta name="keywords" content="{{ $settings['how_it_works_meta_keywords'] ?? '' }}">
@endsection
@section('content')
<!-- content begin -->
<div class="no-bottom no-top" id="content">
    <div id="top"></div>

    <section class="container-banner-lg p-0">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6 col-md-12 col-sm-12 banner-left-heading m-auto">
                    <div class="banner-left-area">
                        <div class="alhamdulillah-dark custom-font-1 mb-3">Alhamdulillah</div>
                        <h1 class="text-dark custom-font-3"><span>Bespoke</span> Online Quran Tutoring that is flexible and affordable</h1>
                        <p class="text-justify text-dark">We aspire our students to attain a greater understanding of The Holy Quran in a manner that is spiritually rewarding and financially feasible.</p>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 asideimg" style="background-image: linear-gradient(0deg, rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url({{ asset('images/bg-1.jpg') }});"></div>
                {{-- <div class="col-lg-6 col-md-6 col-sm-12 asideimg" style="background-image: url({{ asset('images/bg-1.jpg') }});">

                </div> --}}
            </div>
        </div>
    </section>
    <section class="container-banner-md p-0" style="background-image: linear-gradient(0deg, rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url({{ asset('images/bg-1.jpg') }});">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-12 col-sm-12 banner-left-heading m-auto">
                    <div class="banner-left-area">
                        <div class="alhamdulillah-white custom-font-1 mb-3">Alhamdulillah</div>
                        <h1 class="text-white custom-font-3"><span>Bespoke</span> Online Quran Tutoring that is flexible and affordable</h1>
                        <p class="text-justify text-white">We aspire our students to attain a greater understanding of The Holy Quran in a manner that is spiritually rewarding and financially feasible.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-12"></div>
                {{-- <div class="col-lg-6 col-md-6 col-sm-12 asideimg" style="background-image: url({{ asset('images/bg-1.jpg') }});">

                </div> --}}
            </div>
        </div>
    </section>
    <section class="section-lesson bg-white pt-3 pb-3">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 m-auto lessons-left-heading">
                    <div class="alhamdulillah-dark custom-font-1 mb-3">Alhamdulillah</div>
                    <h1><span>High quality,</span> personalised Quran tuition</h1>
                    <p>
                        Learn Quran online with our well versed well qualified teachers who have a vast experience of teaching, Noorani Qaida, Tajweed-ul-Quran and Quran memorization (Hifz).
                    </p>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 p-5">
                    <img src="{{ asset('images/20670.jpg') }}" class="img-fluid p-3" alt="">
                </div>
            </div>
        </div>
    </section>
    <section class="section-fun-learning pb-3">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 p-5">
                    <img src="{{ asset('images/317349455.jpg') }}" class="img-fluid" alt="">
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 m-auto fun-learning-right-heading">
                    <div class="alhamdulillah-dark custom-font-1 mb-3">Alhamdulillah</div>
                    <h1><span>You’ll only pay</span> for what you use</h1>
                    <p>
                        With our rolling monthly program there are no contracts which allow you to pay as you learn and cancel at any time, offering flexibility, control, and freedom to your learning.
                    </p>
                </div>
            </div>
        </div>
    </section>
    <section class="container text-center pb-3">
        <h1 class="demo-title">Get your best desired pricing plan</h1>
        <h3>Start your inquiry session now just go to submit inquiry</h3>
        <div class="pricing-table mt-5">
            @foreach(indexPlans() as $pl)
                <div class="ptable-item">
                    <div class="ptable-single">
                        <div class="ptable-header">
                            <div class="ptable-title">
                                <h2>{{ $pl->name }}</h2>
                            </div>
                            <div class="ptable-price">
                                <h2>{{ $pl->country->currency }}@php echo $discounted_price = $pl->price - $pl->discount;  @endphp<span>/ Hour</span></h2>
                            </div>
                        </div>
                        <div class="ptable-body">
                            <div class="ptable-description">
                                <ul>
                                    <li><i class="fa fa-check-square"></i>{{$pl->days_in_week ?? ''}} days in week</li>
                                    <li><i class="fa fa-check-square"></i>{{$pl->classes_in_month ?? ''}} classes in month</li>
                                    <li><i class="fa fa-check-square"></i>{{$pl->duration ?? ''}} minutes duration</li>
                                    <li><i class="fa fa-check-square"></i>{{ $pl->country->currency }}{{$pl->price_per_month ?? ''}} price per month</li>
                                </ul>
                            </div>

                            <div class="text-center mt-3">
                                <a href="{{ route('enroll') }}" class="btn-custom btn-lg">Submit your inquiry Now!</a>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
          </div>

    </section>
    <section class="section-handpicked pt-3 pb-3" id="inquiry-form">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 m-auto handpicked-right-heading">
                    <h1><span>Are you interested?</span> Sign up for 3-day FREE trial today</h1>
                </div>
                <div style="box-shadow: 10px 10px 52px -20px rgba(0,0,0,0.35);" class="col-lg-6 col-md-6 col-sm-12 m-auto fun-learning-right-heading">

                        @include('admin.partials.success_message')
                            <form name="contactForm" id='contact_form' class="mb-2 p-3" method="post" action="{{ route('enroll_submit') }}">
                                @csrf
                                 <input type="hidden" name="student_time_difference" id="time_zone">
                                @if($errors->has('name'))
                                <div class="alert alert-danger" role="alert">{{ $errors->first('name') }}</div>
                                @endif
                                <div class="field-set">
                                    <label>Enter Your Name</label>
                                    <input type='text' name='name' id='name' class="form-control" placeholder="Your Name">
                                    @if($errors->has('name'))
                                    <div class="alert alert-danger" role="alert">{{ $errors->first('name') }}</div>
                                    @endif
                                </div>
                                <div class="field-set">
                                    <label>Enter Your Email</label>
                                    <input type='text' name='email' id='email' class="form-control" placeholder="Your Email">
                                    @error('email')
                                    <span class="danger" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>
                                <div class="field-set">
                                    <label>Your Phone Number</label>
                                    <input type='text' name='phone' id='phone' class="form-control" placeholder="Your Phone">
                                    @error('phone')
                                    <span class="danger" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>
                                <div class="field-set mb-4">
                                    @if(config('services.recaptcha.key'))
                                        <div class="g-recaptcha"
                                            data-sitekey="{{config('services.recaptcha.key')}}">
                                        </div>
                                    @endif
                                </div>

                                <div class="text-center">
                                    <button type='submit' class="btn btn-custom btn-site">Start Free Trial</button>
                                </div>
                            </form>
                </div>

            </div>
        </div>
    </section>

    <section id="section-faq" class="bg-light-grey">
        <div class="container">
            <div class="row">
                <div class="col text-center ">
                    <h1>Got a question? Call us to ask about our service and how we can assist you.</h1>
                    <div class="spacer-20"></div>
                </div>
            </div>
            <div class="row ">
                <div class="col-md-12 text-center">
                    <a href="" class="btn-custom bg-success btn-lg"><i class="fa fa-whatsapp"></i> Call us</a>
                </div>
            </div>
        </div>
    </section>
</div>
<!-- content close -->

@stop
@section('js')

<script type="text/javascript">
     $(document).ready(function () {
        var d = new Date();
        var n = d.getTimezoneOffset();
        $('#time_zone').val(n);
     });
     
</script>
