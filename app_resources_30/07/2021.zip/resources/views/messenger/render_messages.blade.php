@foreach($messages as $item)
@if($item->user_id == Auth::Id())
<div class="media w-50 ml-auto">
	<div class="bg-dark rounded py-1 px-3 mb-2">
		<p class="text-small mb-0 text-white">{{ $item->message ?? '' }}</p>
	</div>
</div>
@else
<div class="media w-50">
	<div class="bg-light rounded py-1 px-3 mb-2">
		<p class="text-small mb-0 text-dark">{{ $item->message ?? '' }}</p>
	</div>
</div>
@endif
@endforeach
