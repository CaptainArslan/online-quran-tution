

@extends('layouts.app')
@section('title', $settings['blog_meta_title'] ?? '')
@section('meta')

<meta name="description" content="{{ $settings['blog_meta_description'] ?? '' }}">
<meta name="keywords" content="{{ $settings['blog_meta_keyword'] ?? '' }}">
@endsection
@section('css')
<style>
    .pagination {
        justify-content: center;
    }
    .page-item.active .page-link{
        background-color: #3aafa9;
        border-color: #3aafa9;
    }

    .shadow{
      box-shadow: 0 0.5rem 1rem rgb(60 72 88 / 15%) !important;   
    }
    .a-hover{
        
        text-decoration: none !important;
        
    }
    .hover-effect:hover{
        -ms-transform: scale(1.03)!important; /* IE 9 */
        -webkit-transform: scale(1.03)!important; /* Safari 3-8 */
        transform: scale(1.03)!important;
        transition-duration: .5s;
        
    }
    li{
        list-style:none;
        margin-bottom:25px;
       
    }
    
    .card-title{
        margin-bottom:0px;
    }
    @media(max-width:767px)
    {
        .blog-image{
        height:200px;
    }
        .dis-hide{
            display:none!important;
        }
        
    }
    @media(min-width:768px)
    {
        .blog-image{
        height:270px;
    }
        
        .li-right{
            margin-left: 61.01695%; 
            margin-top: -220px;
            width: 38%
        }
        .li-left{
            margin-right: 61.01695%;
            width: 38%
        }
    }
</style>
@endsection
@section('content')
<!-- content begin -->
<div class="no-bottom no-top" id="content">
    <div id="top"></div>

    <section class="container-banner-lg p-0">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6 col-md-12 col-sm-12 banner-left-heading m-auto">
                    <div class="banner-left-area">
                        <h1 class="text-dark custom-font-3">Our <span>Blogs</span></h1>
                        <p class="text-justify text-dark">A regularly updated selection of blog articles to support your teaching.</p>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 asideimg" style="background-image: linear-gradient(0deg, rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url({{ asset($settings['header_banner_image']) }});"></div>
                {{-- <div class="col-lg-6 col-md-6 col-sm-12 asideimg" style="background-image: url({{ asset($settings['header_banner_image']) }});">

                </div> --}}
            </div>
        </div>
    </section>
    <section class="container-banner-md p-0" style="background-image: linear-gradient(0deg, rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url({{ asset($settings['header_banner_image']) }});">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-12 col-sm-12 banner-left-heading m-auto">
                    <div class="banner-left-area">
                        <h1 class="text-white custom-font-3">Our <span>Blogs</span></h1>
                        <p class="text-justify text-white">A regularly updated selection of blog articles to support your teaching.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-12"></div>
                {{-- <div class="col-lg-6 col-md-6 col-sm-12 asideimg" style="background-image: url({{ asset($settings['header_banner_image']) }});">

                </div> --}}
            </div>
        </div>
    </section>

    <section id="section-features" >
        
        <div class="container" style="position:relative;">
            <div class="dis-hide" style="border-left: 1.5px solid #ccc;height: 100%;position: absolute;left: 50%;margin-left: -3px;top: 0;">
                
            </div>
            <div class="row">
                <ul class="list-group-flush list-group w-100">
                    @foreach($blogs as $blog)
                        <li class="@if($loop->iteration % 2 == 0) li-right @else li-left @endif shadow hover-effect">
                            <a href="{{route('blog.detail',['id'=>$blog->id,'slug'=>$blog->slug])}}" class="a-hover">
                                <div class="card">
                                    <div class="card-title">
                                        <img src="{{asset($blog->image)}}" class="w-100 blog-image " style="">
                                    </div>
                                    <div class="card-body p-4">
                                        <h3 class="mb-0">{{$blog->title}}</h3>
                                    </div>
                                </div>
                            </a>
                        </li>
                        
                    @endforeach
                </ul>
                   
            </div>
             
        </div>
        
<div class="row justify-content-center mt-3">
                 {{$blogs->links()}}
             </div>
    </section>
    
</div>
<!-- content close -->

@stop
