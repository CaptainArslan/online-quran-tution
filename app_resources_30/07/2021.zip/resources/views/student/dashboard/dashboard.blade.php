@extends("student.layouts.app")
@section('content')
@include('admin.partials.success_message')

@section('css')
    <style>
        th
        {
        background-color: #F8F8F8;
        font-size: 14px !important;
        text-transform: uppercase;
        font-weight:900;
        }
        td
        {
            font-size: 12px;
            text-transform: uppercase;
            font-weight: bold;
        }
        .btn
        {
            font-size: 12px;
            font-weight: bold;
        }
    </style>
@endsection
@section('topbar-heading', 'Dashboard')

<div class="row">
    <div class="col-xl-3 col-md-4 col-sm-6">
        <div class="card text-center">
          <div class="card-body">
            <h1 class="font-weight-bold text-info">{{ count($inquiries) ?? '0' }}</h1>
            <h4 class="font-weight-bolder"> Total Inquiries</h4>
          </div>
        </div>
      </div>
<div class="col-xl-3 col-md-4 col-sm-6">
        <div class="card text-center">
          <div class="card-body">
            <h1 class="font-weight-bold text-success">{{ count($inquiries->where('status', 'started')) ?? '0' }}</h1>
            <h4 class="font-weight-bolder"> Active Inquiries</h4>
          </div>
        </div>
      </div>
<div class="col-xl-3 col-md-4 col-sm-6">
        <div class="card text-center">
          <div class="card-body">
            <h1 class="font-weight-bold text-warning">{{ count($inquiries->where('status', 'pending')) ?? '0' }}</h1>
            <h4 class="font-weight-bolder"> Pending Inquiries</h4>
          </div>
        </div>
      </div>
<div class="col-xl-3 col-md-4 col-sm-6">
        <div class="card text-center">
          <div class="card-body">
            <h1 class="font-weight-bold text-danger">{{ count($inquiries->where('status', 'cancelled')) ?? '0' }}</h1>
            <h4 class="font-weight-bolder"> Cancelled Inquiries</h4>
          </div>
        </div>
      </div>


</div>


<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="text-center pb-1 pt-1">
                <h3 class="text-uppercase text-info">latest Inquiries</h3>
            </div>
            <div class="card-body p-0">

                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <th>Created</th>
                            <th>Payment Status</th>
                            <th>Inquiry Status</th>
                            <th width="23%" class="text-right">Action</th>
                        </thead>
                        <tbody>
                            @foreach ($inquiries->sortByDesc("id") as $appointment)
                            <tr>
                                <td>{{ $appointment->created_at->diffForHumans() ?? 'N/A' }}</td>
                                <td>
                                    @if($appointment->is_paid)
                                        <span class="badge badge-success">Paid</span>
                                    @else
                                        <span class="badge badge-danger">Not Paid</span>
                                    @endif
                                </td>
                                <td>
                                    <span class="badge badge-primary">{{ str_replace('_', ' ', $appointment->status) }}</span>
                                </td>
                                <td class="text-center">
                                    @php
                                        $diff = \Carbon\Carbon::now()->diffInDays($appointment->created_at);
                                    @endphp

                                    <a href="{{route('student.session',['id'=>base64_encode($appointment->id)])}}" class="btn btn-success btn-block font-weight-bold">View Schedule</a>

                           
                                    
                                    @if($appointment->is_paid == 0 )
                                        <a href="{{ route('student.payments.index', ['id' => base64_encode($appointment->id)]) }}" class="btn btn-primary btn-block font-weight-bold">Pay Inquiry</a>
                                    @endif


                                  

                                </td>

                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-lg-12">
        <h5 class="alert alert-warning">First 3 days after inquiry submission will be marked as a trial days. After the trial period you have to pay your payments against the inquiry to continuee the classes.</h5>
    </div>
    
</div>

@endsection
