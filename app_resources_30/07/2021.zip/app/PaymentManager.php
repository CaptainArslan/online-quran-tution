<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PaymentManager extends Model
{
    //
}
