<?php

namespace App;
use App\Plan;
use Illuminate\Database\Eloquent\Model;

class Subscription extends Model
{
    protected $guarded = [];

  public function plan()
  {
      return $this->belongsTo('App\Plan','plan_id','id');
  }
}
