<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Contact;

class ContactController extends Controller
{
	public function contact_messages()
	{
		$list=Contact::all();
    	return view("admin.contact.list",get_defined_vars());
	}
 
}
