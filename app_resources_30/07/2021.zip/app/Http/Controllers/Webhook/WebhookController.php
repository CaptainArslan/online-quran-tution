<?php

namespace App\Http\Controllers\Webhook;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use PayPal\Rest\ApiContext;
use PayPal\Auth\OAuthTokenCredential;
use PayPal\Api\Payment;
use PayPal\Api\VerifyWebhookSignature;
use PayPal\Api\WebhookEvent;
use App\Subscription;
use App\Inquiry;
use Log;
use App\User;

class WebhookController extends Controller
{
    private $_api_context;

    public function __construct()
    {
        $this->_api_context = new ApiContext(
            new OAuthTokenCredential(config('paypal.client_id'), config('paypal.secret'))
        );
        $this->_api_context->setConfig(config('paypal'));
    }


    public function paypalWebhook(Request $request)
    {


        Log::notice($request->all());

        $request_body = file_get_contents('php://input');

        $respnse = json_decode($request_body, 1);

        $this->updateInquiryWebhookResponse($respnse['resource']['id']);

        exit(1);
    }





    public function gocardlessWebhook(Request $request)
    {

        $request_body = file_get_contents('php://input');
        $response = json_decode($request_body, 1);


        $resp = $response['events'][0];

       // Log::notice($resp);

        if($resp['resource_type'] == 'subscriptions')
        {
            if($resp['action'] == 'cancelled' or $resp['action'] == 'finished' or $resp['action'] == 'paused')
            {
                $this->updateInquiryWebhookResponse($response['events'][0]['links']['subscription']);
            }
        }
        // Log::notice($sub_id);
    }

    public function updateInquiryWebhookResponse($sub_id)
    {
        $subscription = Subscription::where('subscription_id', $sub_id)->first();
        $inq = Inquiry::find($subscription->inquiry_id);
        $inq->update([
            'is_paid' => 0,
            'cancel_subs'=> 0,
        ]);
        $subscription->update(['status'=>'cancelled']);
    }
    
    
    public function gocardlessWebhookFindCharges(Request $request)
    {
        Log::notice($request->all());
        if($request->events[0]['action']=='confirmed')
        {
            $payment_id=$request->events[0]['links']['payment'];
        
            $this->findPayment($payment_id);  
        }
        
    }
    
    public function findPayment($payment_id)
    {
       
        $client = new \GoCardlessPro\Client(array(
          'access_token' => env('GOCARDLESS_ACCESS_TOKEN'),
          'environment'  => \GoCardlessPro\Environment::LIVE,
        ));
        $resp =   $client->payments()->get($payment_id);
        
        $payout_id=$resp->api_response->body->payments->links->payout;
        $subscription_id=$resp->api_response->body->payments->links->subscription;
        
          $client = new \GoCardlessPro\Client(array(
          'access_token' => env('GOCARDLESS_ACCESS_TOKEN'),
          'environment'  => \GoCardlessPro\Environment::LIVE,
        ));

       $pay_out= $client->payouts()->get($payout_id);
        $net_amount=$pay_out->api_response->body->payouts->amount;
        Subscription::where('subscription_id',$subscription_id)->update([
            'payment_confirmed'=>'confirmed',
            'net_amount'=>$net_amount/100,
            ]);
       
    }
    
   
}
