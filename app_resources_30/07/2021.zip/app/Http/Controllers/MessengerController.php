<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Conversation;
use App\Message;
use App\User;
use Auth;




class MessengerController extends Controller
{


	public function messenger($id)
	{
		$user = User::find($id);
        if(!$user)
        {
            return redirect()->route('index');
        }


        $conversation_id = Conversation::where('sender_id', Auth::Id())->where('receiver_id', $id)->pluck('id')->first();
        if(is_null($conversation_id))
        {
            $conversation_id = Conversation::where('receiver_id', Auth::Id())->where('sender_id', $id)->pluck('id')->first();
        }

        if(is_null($conversation_id))
        {
            $conversation_id = Conversation::create([
                'sender_id' => Auth::Id(),
                'receiver_id' => $id
            ]);

            $conversation_id = $conversation_id->id;

        }



        // dd(get_defined_vars());

        if(Auth::user()->role == 'student')
        {
		    return view('student.messenger.student_messenger', get_defined_vars());
        }

        return view('tutor.messenger.tutor_messenger', get_defined_vars());
	}


	public function getChat(Request $req)
    {

        $messages = Message::where('conversation_id', $req->id)->get();
        return view('messenger.render_messages', get_defined_vars());
    }

    public function saveMessage(Request $req)
	{

		// dd($req->all());

        // $con = $req->convo_id;

        // if(is_null($req->convo_id))
        // {
        //     $con = Conversation::create([
        //         'sender_id' => Auth::Id(),
        //         'receiver_id' => $req->receiver_id
        //     ]);

        //     $con = $con->id;
        // }


        $m = new Message();
        $m->conversation_id = $req->con_id;
		$m->user_id = Auth::Id();
		$m->message = $req->message;
		$m->ip = $req->ip();
        $m->save();

		return response()->json('sent');
	}



}
