<?php

namespace App\Http\Controllers;

use App\HomeVideo;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Traits\SaveTutor;
use Illuminate\Foundation\Auth\VerifiesEmails;
use App\Plan;
use App\User;
use App\Faq;
use GuzzleHttp\Client;
use function GuzzleHttp\Promise\settle;
use App\Country;
use App\Blog;
use App\Review;
use App\Traits\PayPalPlansApi;
use App\Testimonial;
use App\Subscription;
use App\Inquiry;
use Carbon\Carbon;
use App\InquirySchedule;
use App\TutorReviews;



class HomeController extends Controller
{
    use SaveTutor;
    use VerifiesEmails;
    use PayPalPlansApi;

    public function index()
    {



        $total_tutors   = User::where('role', 'tutor')->count();
        $total_students = User::where('role', 'student')->count();
        $faqs = Faq::all();
        $review = Testimonial::where('status', 1)->where('rating', 5)
            ->orWhere('rating', 4)->orWhere('rating', 3)->orWhere('rating', 2)
            ->orWhere('rating', 1)->count();
        
        $videos=HomeVideo::all();
        return view('index', get_defined_vars());
    }
    public function teach_with_us()
    {
        return view('teach_with_us');
    }
    public function add_teacher(Request $request)
    {
        $id = $request->id;
        $this->add_tutor($request);
        if ($id == 0) {
            return redirect()->back()->with('message', 'You have been successfully registered as a tutor.');
        } else {
            return redirect()->back()->with('message', 'Tutor Updated successfully');
        }
    }

    public function enroll($plan_id = 0)
    {
        return view('enroll', get_defined_vars());
    }

    public function pricing()
    {
        return view('pricing');
    }

    public function courses()
    {
        return view('courses');
    }

    public function how_it_works()
    {
        $faqs = Faq::all();
        return view('how_it_works', get_defined_vars());
    }
    public function terms()
    {
        return view('terms');
    }

    public function privacy()
    {
        return view("privacy");
    }

    public function login()
    {
        // Logout any previous user if loged in
        if (Auth::check())
            Auth::logout();
        return view('login');
    }
    public function check_user()
    {


        if (!Auth::check())
            return redirect('admin/login');
        $user = Auth::user();

        if ($user->role === "admin" || $user->role === "manager") {

            return redirect()->route('admin.dashboard');
        }
        /* if ($user->role === "manager") {
            return redirect('admin/shared/dashboard');
            //return route('payment_manager/dashboard');
        }*/
        if ($user->role === "tutor") {
            return redirect('tutor/appointments');
        }

        if ($user->role === "student") {
            return redirect('student/dashboard');
        }
    }

    function getLocation()
    {

        $url = 'http://api.ipinfodb.com/v3/ip-city/?key=345f70aec9a0975ea4290c4cf8c4276dbf8ce326c3946825467d68ea27bb185d&format=json';

        $s = curl_init();
        curl_setopt($s, CURLOPT_URL, $url);
        curl_setopt($s, CURLOPT_RETURNTRANSFER, 1);
        $res = curl_exec($s);
        curl_close($s);
        $r = json_decode($res);

        if ($r->statusCode == 'OK') {
            return $r;
        }
        return 'FAILED';
    }
    public function blogs($tag = null)
    {
      if (!$tag == null) {

            $blogs = Blog::where(function ($query) use ($tag) {
                $query->orWhere('meta_keywords', 'like', '%' . $tag . '%')->where('visibility', 'showed');
            })->paginate(10);
        } else {

            $blogs = Blog::where('visibility', 'showed')->paginate(10);
        }

        return view('blogs', get_defined_vars());
    }
    public function blog_detail(Request $request, $id, $slug = null)
    {
        $blog = Blog::find($id);
        $recent_blogs = Blog::orderBy('id', 'desc')->take(5)->get();
        return view('blog-details', get_defined_vars());
    }

    public function testimonials()
    {
        $testimonials = Testimonial::where('status', 1)->orderBy('id', 'DESC')->paginate(10);
       
        $total_testimonials=Testimonial::where('status', 1)->where('rating', 5)
            ->orWhere('rating', 4)->orWhere('rating', 3)->orWhere('rating', 2)
            ->orWhere('rating', 1)->get();
           
        $avg = Testimonial::where('status', 1)->avg('rating');

        $star5 = Testimonial::where('status', 1)->where('rating', 5)->count();
        $star4 = Testimonial::where('status', 1)->where('rating', 4)->count();
        $star3 = Testimonial::where('status', 1)->where('rating', 3)->count();
        $star2 = Testimonial::where('status', 1)->where('rating', 2)->count();
        $star1 = Testimonial::where('status', 1)->where('rating', 1)->count();
        $videos=HomeVideo::all();
        return view("testimonials", get_defined_vars());
    }
    
    
    
    
    public function checkSub($id)
    {
        $client = new \GoCardlessPro\Client(array(
          'access_token' =>  env('GOCARDLESS_ACCESS_TOKEN'),
          'environment'  => \GoCardlessPro\Environment::SANDBOX
        ));

       dd($client->subscriptions()->get($id));

    }
    
    
   
    
    
}
