<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PayOut extends Model
{
    protected $fillable = [];
    public function tutor()
    {
        return $this->belongsTo('App\User','tutor_id');
    }
    public function manager()
    {
        return $this->belongsTo('App\User','manager_id');
    }
    
}
