<?php

namespace App\Exports;

use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromView;
use App\Inquiry;

class NotPaidInquiry implements FromView
{
	protected $data;
    function __construct($data)
    {
    	$this->data = $data;
    }
	public function view(): View
	{
		return view('admin.exports.not_paid_inquiry', [
			'notPaidInquirys'=>$this->data
		]);
	}
}
